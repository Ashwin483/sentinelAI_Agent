# Combined project

Windows project: `D:\team-b-sentinel`
Kali execution folder: `/home/kali/sentinel-five-agent-lab`

All five agents run from `sentinel/core.py` through `start.py`. Windows generates supported SQL patches; the SSH executor on Kali tests and applies them. Brute force uses gateway cooldowns, not source repair. Read START-HERE.md for the complete setup.

The uploaded gateway/core/startup/dashboard were upgraded to the five-node LangGraph version. Unchanged shared files are retained. Replaced files and other historical scripts, PDF documentation and reports are preserved under `legacy/` for reference, not runtime use. The main README describes current limitations. This is one combined project; do not start both old and new repair controllers.

No virtual environments, live databases or credentials are redistributed. Back up the old Windows folder before extraction to retain your local settings and incident history. The new project starts with fresh state and generated API tokens.

## Unchanged shared files
- `collector.py`
- `lab_app.py`
- `pytest.ini`
- `sentinel/__init__.py`
- `setup_env.py`
- `tests/lab_fixture.txt`

## Archived original files
- `legacy/.env.example`
- `legacy/.gitignore`
- `legacy/auto_repair_agent.py`
- `legacy/Full-Guide.md`
- `legacy/patch_lab.py`
- `legacy/README.md`
- `legacy/repair_bridge.py`
- `legacy/replay_local.py`
- `legacy/requirements-kali.txt`
- `legacy/requirements-windows.txt`
- `legacy/requirements.txt`
- `legacy/sentinel/core.py`
- `legacy/sentinel/web.py`
- `legacy/START-HERE.md`
- `legacy/start.py`
- `legacy/Team-B-Self-Healing-Guide.pdf`
- `legacy/tests/auto_repair_agent.py`
- `legacy/tests/repair_bridge.py`
- `legacy/tests/requirements-kali.txt`
- `legacy/tests/requirements-windows.txt`
- `legacy/tests/START-HERE.md`
- `legacy/tests/tests/lab_fixture.txt`
- `legacy/tests/tests/test_agent.py`
- `legacy/tests/test_agent.py`
- `legacy/tests/test_system.py`
- `legacy/tests/VALIDATION.txt`
- `legacy/validation/baseline-tests.txt`
- `legacy/validation/candidate-tests.txt`
- `legacy/validation/patch-result.json`
- `legacy/validation/post-apply-tests.txt`
- `legacy/validation/proposed.patch`
- `legacy/validation/socket-validation.json`
- `legacy/validation/test-summary.json`
- `legacy/VALIDATION.txt`
- `legacy/website/app.js`
- `legacy/website/index.html`
- `legacy/website/style.css`
- `legacy/WEBSITE.md`
