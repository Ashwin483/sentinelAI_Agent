"""Windows: authenticated Sentinel incident feed -> pinned SSH Kali repair worker."""
import argparse
import base64
import getpass
import hashlib
import hmac
import ipaddress
import json
from pathlib import Path
import shlex
import socket
import time
import uuid

import httpx
import paramiko
from dotenv import dotenv_values


def eligible(event, cutoff, seen):
    try:
        uuid.UUID(event['id'])
        return (event['id'] not in seen and float(event['created']) >= cutoff
                and event.get('label') == 'sql_injection'
                and event.get('path') == '/products' and event.get('origin') == 'gateway')
    except (KeyError, ValueError, TypeError, AttributeError):
        return False


def fingerprint(key):
    return 'SHA256:' + base64.b64encode(hashlib.sha256(key.asbytes()).digest()).decode().rstrip('=')


class Messages:
    def __init__(self, channel):
        self.channel, self.buffer = channel, b''

    def receive(self, timeout):
        deadline = time.monotonic() + timeout
        while True:
            if b'\n' in self.buffer:
                line, self.buffer = self.buffer.split(b'\n', 1)
                return json.loads(line)
            if self.channel.recv_stderr_ready():
                # Worker diagnostics only; never print admin token or password.
                print(self.channel.recv_stderr(4096).decode(errors='replace'), end='', flush=True)
            if self.channel.recv_ready():
                chunk = self.channel.recv(4096)
                if not chunk:
                    raise ConnectionError('Kali worker disconnected')
                self.buffer += chunk
                if len(self.buffer) > 131072:
                    raise ValueError('Oversized worker response')
                continue
            if self.channel.exit_status_ready() or self.channel.closed:
                raise ConnectionError('Kali worker stopped; check diagnostics above')
            if time.monotonic() >= deadline:
                return None
            time.sleep(0.05)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--kali-ip', default='192.168.189.128')
    parser.add_argument('--user', default='kali')
    parser.add_argument('--app-port', type=int, default=9002)
    parser.add_argument('--host-fingerprint', required=True)
    parser.add_argument('--lab-path', default='/home/kali/sentinel-vulnerable-lab')
    args = parser.parse_args()
    address = ipaddress.ip_address(args.kali_ip)
    if address.version != 4 or not address.is_private or address.is_unspecified:
        parser.error('Use the private IPv4 address of your Kali VM')
    root = Path(__file__).resolve().parent
    token = dotenv_values(root / '.env').get('ADMIN_TOKEN')
    if not token:
        raise RuntimeError('ADMIN_TOKEN missing from .env beside repair_bridge.py')
    cutoff, seen = time.time(), set()
    with httpx.Client(base_url='http://127.0.0.1:8000', trust_env=False, timeout=5,
                      headers={'Authorization': 'Bearer ' + token}) as api:
        response = api.get('/api/state')
        response.raise_for_status()
        if response.json().get('mode') != 'live':
            raise RuntimeError('Expected the live Sentinel API')
        sock = socket.create_connection((args.kali_ip, 22), timeout=10)
        transport = paramiko.Transport(sock)
        channel = None
        try:
            transport.get_security_options().key_types = ('ssh-ed25519',)
            transport.start_client(timeout=10)
            actual = fingerprint(transport.get_remote_server_key())
            if not hmac.compare_digest(actual, args.host_fingerprint):
                raise RuntimeError('SSH fingerprint mismatch. Check the fingerprint in the Kali terminal.')
            password = getpass.getpass('Kali login password (hidden): ')
            transport.auth_password(args.user, password)
            del password
            transport.set_keepalive(15)
            channel = transport.open_session(timeout=10)
            channel.settimeout(10)
            command = ('cd ' + shlex.quote(args.lab_path)
                       + ' && exec .venv/bin/python -u auto_repair_agent.py --host '
                       + shlex.quote(args.kali_ip) + ' --port ' + str(args.app_port))
            channel.exec_command(command)
            messages = Messages(channel)
            ready = messages.receive(30)
            if not ready or ready.get('type') != 'ready':
                raise RuntimeError('Kali worker did not become ready')
            print('READY: watching new /products SQL incidents. Keep this terminal open.', flush=True)
            while True:
                message = messages.receive(0.1)
                if message:
                    print(json.dumps(message), flush=True)
                try:
                    response = api.get('/api/state')
                    response.raise_for_status()
                    events = response.json()['incidents']
                except (httpx.HTTPError, KeyError, ValueError) as exc:
                    print('Sentinel feed unavailable:', type(exc).__name__, flush=True)
                    time.sleep(2)
                    continue
                for event in sorted(events, key=lambda e: e.get('created', 0)):
                    if not eligible(event, cutoff, seen):
                        continue
                    seen.add(event['id'])
                    trigger = {key: event[key] for key in ('id', 'label', 'path')}
                    channel.sendall((json.dumps(trigger) + '\n').encode())
                    print('REPAIR STARTED:', event['id'], flush=True)
                    deadline = time.monotonic() + 120
                    while True:
                        reply = messages.receive(2)
                        if reply:
                            print(json.dumps(reply), flush=True)
                            if reply.get('type') == 'error':
                                raise RuntimeError('Worker rejected incident; see error above')
                            if reply.get('type') == 'result':
                                if reply['report']['incident_id'] != event['id']:
                                    raise RuntimeError('Unexpected incident result')
                                with open(root / 'repair-events.jsonl', 'a', encoding='utf-8') as log:
                                    log.write(json.dumps(reply['report']) + '\n')
                                break
                        if time.monotonic() >= deadline:
                            raise TimeoutError('Repair outcome unknown; inspect Kali latest-report.json before retrying')
                time.sleep(2)
        finally:
            if channel:
                # EOF requests a clean shutdown after any in-progress repair completes.
                try:
                    channel.shutdown_write()
                    deadline = time.monotonic() + 15
                    while not channel.exit_status_ready() and time.monotonic() < deadline:
                        if channel.recv_ready():
                            channel.recv(4096)
                        time.sleep(0.1)
                finally:
                    channel.close()
            transport.close()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nBridge stopped. The worker normally stops its owned lab server on disconnect.')
    except Exception as exc:
        print('STOPPED:', str(exc))
        raise SystemExit(1)
