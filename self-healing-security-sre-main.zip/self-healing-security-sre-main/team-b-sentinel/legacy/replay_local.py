"""Bounded replay against loopback only. Never accepts a remote target."""
import argparse
import asyncio
import httpx

async def main(case):
    async with httpx.AsyncClient(trust_env=False, base_url='http://127.0.0.1:8080',timeout=10) as c:
        if case=='sql':
            r=await c.get('/products',params={'q':"' OR 1=1--"});print('SQL signature request:',r.status_code,'(expected 403 or active-rule 429)')
            r=await c.get('/products',params={'q':'book'});print('Normal search:',r.status_code,'(expected 200)')
        elif case=='brute':
            for i in range(6):
                r=await c.post('/login',json={'username':'student','password':'incorrect'});print('Login',i+1,r.status_code)
                await asyncio.sleep(.1)
        else:
            statuses={}
            for _ in range(65):
                r=await c.get('/products',params={'q':'book'});statuses[r.status_code]=statuses.get(r.status_code,0)+1
            print('65 sequential loopback requests:',statuses)
            print('This is a bounded HTTP threshold check, not a real distributed DDoS test.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('case',choices=['sql','brute','flood']);a=p.parse_args();asyncio.run(main(a.case))
