"""Actual source repair in a disposable known fixture. Never modifies your application."""
import argparse
import difflib
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import TypedDict
from langgraph.graph import StateGraph, START, END

BEFORE = '''import sqlite3

def search(value):
    with sqlite3.connect(":memory:") as db:
        db.executescript("CREATE TABLE items(name TEXT); INSERT INTO items VALUES ('book'), ('pen');")
        return db.execute("SELECT name FROM items WHERE name = '" + value + "'").fetchall()
'''
AFTER = '''import sqlite3

def search(value):
    with sqlite3.connect(":memory:") as db:
        db.executescript("CREATE TABLE items(name TEXT); INSERT INTO items VALUES ('book'), ('pen');")
        return db.execute("SELECT name FROM items WHERE name = ?", (value,)).fetchall()
'''
TESTS = '''from target import search

def test_normal_search():
    assert search("book") == [("book",)]

def test_suspicious_input_is_data():
    assert search("' OR 1=1--") == []

def test_apostrophe_is_valid_data():
    assert search("O'Reilly") == []
'''

class State(TypedDict, total=False):
    original_hash: str
    baseline_code: int
    candidate_code: int
    result: str


def run(output: Path):
    output.mkdir(parents=True, exist_ok=True)
    target = output/'target.py'
    if target.exists():
        raise SystemExit('Output already contains target.py. Keep it for audit, or choose a NEW --output directory.')
    target.write_text(BEFORE)
    (output/'target.py.before').write_text(BEFORE)
    (output/'test_target.py').write_text(TESTS)

    def test(code):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'target.py').write_text(code);(p/'test_target.py').write_text(TESTS)
            result=subprocess.run([sys.executable,'-m','pytest','-q','test_target.py'],cwd=p,capture_output=True,text=True,timeout=20,
                                  env={**os.environ,'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'})
            return result

    def investigate(s):
        result=test(BEFORE);(output/'baseline-tests.txt').write_text(result.stdout+result.stderr)
        return {'original_hash':hashlib.sha256(BEFORE.encode()).hexdigest(),'baseline_code':result.returncode}

    def repair(s):
        diff=''.join(difflib.unified_diff(BEFORE.splitlines(True),AFTER.splitlines(True),fromfile='a/target.py',tofile='b/target.py'))
        (output/'proposed.patch').write_text(diff)
        return {}

    def validate(s):
        result=test(AFTER);(output/'candidate-tests.txt').write_text(result.stdout+result.stderr)
        return {'candidate_code':result.returncode}

    def apply(s):
        if hashlib.sha256(target.read_bytes()).hexdigest()!=s['original_hash']:
            return {'result':'aborted: source changed after investigation'}
        temp=target.with_suffix('.tmp');temp.write_text(AFTER);temp.replace(target)
        result=test(target.read_text());(output/'post-apply-tests.txt').write_text(result.stdout+result.stderr)
        if result.returncode:
            target.write_text(BEFORE)
            return {'result':'rolled_back: post-apply tests failed'}
        return {'result':'repaired: known local fixture only; production source unchanged'}

    def escalate(s):return {'result':'escalated: baseline or candidate tests unexpected'}
    g=StateGraph(State)
    for name,node in [('investigate',investigate),('repair',repair),('validate',validate),('apply',apply),('escalate',escalate)]:g.add_node(name,node)
    g.add_edge(START,'investigate');g.add_edge('investigate','repair');g.add_edge('repair','validate')
    g.add_conditional_edges('validate',lambda s:'apply' if s['baseline_code']==1 and s['candidate_code']==0 else 'escalate')
    g.add_edge('apply',END);g.add_edge('escalate',END)
    result=g.compile().invoke({})
    (output/'result.json').write_text(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('patch-output'));args=parser.parse_args()
    print(json.dumps(run(args.output),indent=2))
