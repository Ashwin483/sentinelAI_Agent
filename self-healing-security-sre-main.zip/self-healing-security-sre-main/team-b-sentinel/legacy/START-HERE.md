# Team B: automatic SQL repair addon

Your Windows Sentinel detects the attack. This addon sends the incident over SSH to a Kali worker. The worker fixes the specific SQL query you shared, tests it, restarts the lab website, checks it over HTTP, and restores the original file if verification fails.

This is a running LangGraph repair workflow with a predefined, reviewed patch. It does not ask an LLM to invent or execute code. No model API key is required. It repairs the known `/products` SQL vulnerability only. Brute-force protection and request-rate limiting remain separate Sentinel features; this addon does not automatically patch those vulnerabilities.

## 1. Where the files go

| Machine | Folder | Purpose |
|---|---|---|
| Windows | `D:\team-b-sentinel` | Existing Sentinel and new `repair_bridge.py` |
| Kali | `/home/kali/sentinel-vulnerable-lab` | Existing `unsafe_demo.py` and new `auto_repair_agent.py` |

The addon does not replace your Windows project or your whole Kali app. It edits only two recognized SQL expressions in the Kali file. Additional routes remain in the file, but this first version's regression suite covers only product search and health.

Use Python 3.12 or 3.13. The packaged tests were run on Python 3.12.14 in the build environment; your Windows/Kali deployment still needs the final test below.

## 2. Prepare SSH in Kali

Run in a **Kali terminal**:

```bash
sudo apt update
sudo apt install -y openssh-server
sudo systemctl start ssh
ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub -E sha256
```

SSH lets your Windows controller run the worker on your Kali VM. The last command prints a fingerprint such as `SHA256:...`. Copy that entire fingerprint field, excluding the surrounding key size, comment and `(ED25519)`. It is a public identifier, not a password.

Keep your existing VMware NAT configuration. The commands below use the addresses you provided: Kali `192.168.189.128`; Windows VMnet8 `192.168.189.1`. If Kali's IP changes, substitute its new private address throughout and update Windows `UPSTREAM_URL`.

## 3. Extract the download on Windows

Save `Team-B-Auto-Repair.zip` in your Windows Downloads folder. Open **PowerShell**, then run:

```powershell
cd D:\team-b-sentinel
Expand-Archive -Path "$env:USERPROFILE\Downloads\Team-B-Auto-Repair.zip" -DestinationPath .\auto-repair
Copy-Item .\auto-repair\repair_bridge.py .\repair_bridge.py
```

Use a separate environment for the bridge, so its dependencies do not replace Sentinel's packages:

```powershell
.\.venv\Scripts\python.exe -m venv .repair-venv
.\.repair-venv\Scripts\python.exe -m pip install -r .\auto-repair\requirements-windows.txt
```

Transfer the Kali worker and its dependency list:

```powershell
scp .\auto-repair\auto_repair_agent.py .\auto-repair\requirements-kali.txt kali@192.168.189.128:/home/kali/sentinel-vulnerable-lab/
```

If SSH asks whether you trust the server, compare its fingerprint with the one displayed directly in Kali in step 2. Accept only a match, then enter your Kali account password. The password will not appear while you type.

If `scp` is unavailable, use VMware shared folders or copy these two downloaded files into the Kali lab folder with the file manager.

## 4. Install the Kali dependencies

Run in **Kali**:

```bash
cd ~/sentinel-vulnerable-lab
source .venv/bin/activate
python -m pip install -r requirements-kali.txt
python -m py_compile unsafe_demo.py auto_repair_agent.py
```

The last command checks syntax. No output means syntax passed. If your first line is actually `mport sqlite3`, correct that typo to `import sqlite3` first. The SQL repair worker will not guess at unrelated syntax errors.

Now go to the Kali terminal that is running Uvicorn on port 9002 and press **Ctrl+C once**. The repair worker will start and own this app process from now on. Do not start another Uvicorn instance on that port.

Check that the old server stopped:

```bash
ss -ltnp 'sport = :9002'
```

A header with no listening row is expected. If a listener remains, stop it from the terminal that launched it. Do not kill unrelated Python processes.

## 5. Keep Sentinel running on Windows

Your Windows `.env` must retain your existing secret tokens and contain:

```dotenv
START_LAB=false
UPSTREAM_URL=http://192.168.189.128:9002
```

The bridge reads `ADMIN_TOKEN` from this same `.env`. Do not paste that token into chat or into a URL.

If Sentinel is already running, keep it running. Otherwise, in a **Windows PowerShell terminal**:

```powershell
cd D:\team-b-sentinel
.\.venv\Scripts\python.exe start.py
```

Leave this terminal open. Starting Sentinel twice causes the port 8000/8080 conflict you previously saw. Until the bridge starts the Kali app, the gateway may temporarily report `Upstream unavailable`.

## 6. Start automatic repair from Windows

Open a **second Windows PowerShell terminal**:

```powershell
cd D:\team-b-sentinel
$fingerprint = Read-Host "Paste the SHA256 fingerprint from the Kali terminal"
.\.repair-venv\Scripts\python.exe repair_bridge.py --kali-ip 192.168.189.128 --host-fingerprint $fingerprint
```

Enter your Kali login password when prompted. It is used in memory for SSH authentication and is not written to the repair logs.

Expected output:

```text
READY: watching new /products SQL incidents. Keep this terminal open.
```

The worker has now started the Kali app. A health message appears approximately every 10 seconds. `"healthy": true` means the worker's app process is alive and `/health` returns the expected response. It does not mean every possible vulnerability has been fixed.

The bridge polls Sentinel every two seconds. It handles new gateway SQL-injection incidents for `/products` created since this bridge launch. It ignores older incidents, collector events and other attack types. This is a small lab poller, not a durable production event queue: events outside Sentinel's latest-100 snapshot can be missed under heavy load.

## 7. Trigger one local lab test

In a **third Windows PowerShell terminal**, verify ordinary search:

```powershell
curl.exe "http://127.0.0.1:8080/products?q=Mouse"
```

Then send one SQL-injection test through the gateway you own:

```powershell
curl.exe --get --data-urlencode "q=' OR 1=1--" "http://127.0.0.1:8080/products"
```

A gateway rejection is expected. Watch the bridge terminal for `REPAIR STARTED`, then a result containing `"status": "repaired"`.

If the gateway returns `Temporary security rule` and there is no new incident, an earlier rule already blocked the request before detection. Wait until that rule expires in your local Sentinel dashboard, then repeat this single test. Do not turn off the gateway. Sentinel also deduplicates matching incidents for about 30 seconds.

You do not need to paste SQL replacement code or restart the website manually after this trigger.

## 8. Prove the source was repaired

Run these in **Kali** after the bridge reports `repaired`:

```bash
cd ~/sentinel-vulnerable-lab
source .venv/bin/activate
python -m unittest -v test_sql_repair
```

Your existing three tests should now report `OK`. The addon also runs its own equivalent tests internally; it does not depend on your test filename being correct.

Check the app directly, bypassing the gateway for this one verification:

```bash
curl --get --data-urlencode "q=' OR 1=1--" "http://192.168.189.128:9002/products"
```

Expected:

```json
{"products":[]}
```

This direct result distinguishes a source repair from a gateway merely blocking the payload. Normal search should still return Mouse:

```bash
curl "http://192.168.189.128:9002/products?q=Mouse"
```

Read the repair record:

```bash
python -m json.tool repair-runs/latest-report.json
```

## 9. What each LangGraph step does

| Step | Action | Why |
|---|---|---|
| Investigate | Runs normal, injection and apostrophe checks against a saved baseline | Confirms the original behavior |
| Plan | Matches the approved query structure and creates a parameterized candidate | Treats input as data |
| Test | Runs all three checks against the candidate in a separate Python process | Rejects a broken candidate before applying |
| Apply | Checks for concurrent edits, backs up the file, writes the patch and restarts its app | Makes the tested source live |
| Verify | Calls the running `/health` and `/products` endpoints | Confirms the live website behaves correctly |
| Rollback on failure | Restores the hash-checked backup and checks app health | Recovers from a failed deployment when possible |
| Record | Saves the result, test logs, hashes and execution trace | Lets you inspect what happened |

The patch changes string concatenation to a `?` placeholder and passes `(q,)` separately to SQLite. An apostrophe remains ordinary input, and an injected SQL expression no longer changes the query's meaning.

LangGraph coordinates these steps; the steps are ordinary Python functions. Calling them agents does not mean each one needs an LLM. This first repair is deterministic and narrowly scoped so the result is easy to study and test.

## 10. Monitor, stop and recover

On Windows, repairs are appended to `D:\team-b-sentinel\repair-events.jsonl`. In Kali, each incident gets a folder under `repair-runs` containing the baseline, candidate, diff, test logs, backup when applied, and report. `repair-runs/app.log` contains the owned app's server output.

The existing Sentinel dashboard continues to show detection and gateway mitigation. This addon does **not** add a source-repair panel to that dashboard. The bridge console and repair records are the source-repair status.

Status meanings:

- `repaired`: candidate tests and live HTTP checks passed.
- `already_safe`: the approved fix was already present and passed verification.
- `refused`: unknown source, failing candidate or concurrent edit prevented application.
- `rolled_back`: application or verification failed; the backup was restored and app health passed.
- `manual_intervention_required`: rollback could not safely complete. Inspect the recorded error and backup before editing.

Keep both Windows terminals running for continuous detection and repair. Pressing Ctrl+C in the bridge requests worker shutdown and stops the app it owns. This lab addon is not installed as a Windows or Linux startup service and does not automatically reconnect after SSH loss. Restart step 6 after investigating a disconnect; historical events are not automatically replayed.

A pending repair journal is checked at the next worker startup. The worker restores a matching backup for an interrupted deployment, but refuses to overwrite a file someone has changed independently. Do not edit `unsafe_demo.py` while a repair is in progress. A forced kill or power loss may require you to stop a leftover app process before restarting the worker.

Keep this intentionally vulnerable learning app inside your own VM lab. NAT is not a complete security boundary and the app is reachable from the host on its private IP; do not configure public port forwarding.

## Validation and limits

See `VALIDATION.txt` for the actual build test results. The tests use temporary copies of the vulnerable source, real app subprocesses and real loopback HTTP. Your Windows machine and Kali VM were not accessed during the build. A local SSH integration test also passed using a simulated Sentinel feed. Your actual Windows-to-Kali connection and existing Sentinel deployment must still be verified using steps 6–8.

The approved repair is limited to the exact semantic SQL template in your shared code. If you change the table, columns or function structure, it will request human review rather than attempt an arbitrary rewrite. It does not guarantee detection of every SQL injection or remediate unrelated SQL queries, brute force, or volumetric DDoS. Repair restarts briefly interrupt this lab app.

References:

- [LangGraph graph API](https://docs.langchain.com/oss/python/langgraph/graph-api)
- [OWASP SQL injection prevention: parameterized queries](https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html)
- [Paramiko SSH transport and host-key authentication](https://docs.paramiko.org/en/stable/api/transport.html)
