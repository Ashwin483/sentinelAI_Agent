# Sentinel - Team B

Live SQL injection, failed-login and HTTP flood detection with LangGraph response agents and a website dashboard. This is a runnable project prototype, not a production WAF or a guarantee against all attacks.

## Start on Windows

Extract the ZIP. Open the extracted `team-b-sentinel` folder in VS Code, then open Terminal > New Terminal. Use Python 3.12 (the version used for validation).

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe setup_env.py
.\.venv\Scripts\python.exe start.py
```

Keep that terminal running. Open **http://127.0.0.1:8000** in your browser. Open `.env` locally, copy only the value after `ADMIN_TOKEN=`, and paste it into the dashboard. API address: `http://127.0.0.1:8000`. Click **Connect**.

The management dashboard uses port 8000. Your protected application is accessed through port 8080. The example application runs on port 9000 and binds only to loopback. Requests made directly to port 9000 bypass the gateway.

If you already have a compatible Python installed and `py -3.12` is unavailable, select that interpreter explicitly. The supplied dependency versions and tests were checked with Python 3.12 on Linux; Windows commands are provided but have not been executed on a Windows host.

## Test live detection

Open a SECOND terminal in the same folder while `start.py` keeps running:

```powershell
.\.venv\Scripts\python.exe replay_local.py sql
.\.venv\Scripts\python.exe replay_local.py brute
.\.venv\Scripts\python.exe replay_local.py flood
```

These scripts target loopback only and have fixed small request counts. Test SQL and login cases before the flood case, since the flood rule temporarily blocks your source. Default rule expiry: 120 seconds. Counts in the 10-second rate window carry over between cases. Failed-login memory lasts 60 seconds. The dashboard polls every 3 seconds.

Expected: SQL 403 (or 429 under an active rule), normal search 200, five failed logins 401 then subsequent login 429, and flood requests eventually 429. A SQL signature does not establish that a database was compromised. The example application's query is already parameterized.

## Run the tests and source-repair demonstration

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe patch_lab.py
```

`patch_lab.py` builds a disposable unsafe SQL fixture, runs real failing regression tests, generates a parameterized-query diff, tests it, checks the original hash, applies the fix to that fixture, then tests again. Inspect `patch-output/proposed.patch`, `result.json`, and the test logs. It never rewrites your production source. To run again, retain your first evidence and choose another folder:

```powershell
.\.venv\Scripts\python.exe patch_lab.py --output patch-output-2
```

## Architecture

Traffic -> HTTP gateway -> safe example app. Normalized incidents -> bounded queue -> LangGraph investigator -> planner -> validator -> applier -> verifier -> recorder. Failed post-change verification -> rollback -> recorder. Failed preconditions or ambiguous aggregate pressure -> escalation. SQLite stores incident history, rules and audit records. The graph is not durably checkpointed; an interrupted run is marked for review after restart.

## Automatic actions

- SQL injection: fast signature rejection and an expiring route-scoped SQL guard. A source-fix example is attached for review.
- Brute force: an expiring source-and-login-route cooldown, based on actual 401 responses at `/login`.
- HTTP source flood: an expiring source block. Aggregate multi-source pressure is flagged and escalated; baseline overload guards still apply.
- Verification: policy behavior, healthy upstream before apply, active rule and upstream health after apply. This is an immediate check, not a sustained service-level recovery proof.
- Rollback: disable the specific additional rule. Base detector thresholds continue to protect the application.

## Optional AI model

Leave `OLLAMA_MODEL=` blank to run the deterministic LangGraph agents without an LLM. For AI-written explanations, run a local Ollama model, set its installed name in `OLLAMA_MODEL`, and restart. `OLLAMA_URL` defaults to `http://127.0.0.1:11434`. The model receives structured evidence, has no shell or deployment tools, and cannot change detection labels or authorize actions. Timeout: 8 seconds; automatic rule logic still works when inference fails. Downloading packages or a model needs internet; the local runtime can operate offline afterward. No model accuracy or inference speed was measured here.

## Connect an existing application

In `.env`, set `START_LAB=false`, set `UPSTREAM_URL` to your fixed application origin, and configure `LOGIN_PATH`. The app must provide a `/health` route returning 200. Send application traffic to port 8080. Keep the upstream port private so it cannot bypass inspection. This simple gateway ignores all forwarded client-IP headers; do not place it behind another proxy without implementing and testing trusted-proxy handling. TLS must terminate before the gateway inspects plaintext HTTP.

For application logs, produce one normalized JSON object per line and run:

```powershell
.\.venv\Scripts\python.exe collector.py events.jsonl
```

Use `--from-start` only for a historical replay; detection uses arrival time, so historical bursts can look like live floods. The collector accepts normalized JSONL, not raw IIS/Windows event log formats. It has bounded retries but no durable delivery spool. Use stable unique `event_id` values to deduplicate retries.

Event example:

```json
{"event_id":"login-0001","source_ip":"192.0.2.10","method":"POST","path":"/login","status":401,"auth_failed":true}
```

Set `auth_failed` only from a trusted authentication result. Never take it from a browser field or infer failure solely from request contents. Avoid logging passwords, authorization headers or cookies. Collector actions can only enforce at the included gateway. OS login events require another trusted adapter, which is not included.

## Website modes

The published website offers labeled demo incidents and can connect to a separately deployed HTTPS management API with an exact allowed CORS origin. It does not host Python, capture your computer's traffic, or secretly connect to localhost. Use the local dashboard at port 8000 for the simplest live setup. Tokens stay in page memory, not browser storage. The uploaded source archives and any `.env` secrets are excluded from the hosted site.

## Limits

This prototype is for modest HTTP lab traffic. It does not detect network SYN/UDP floods or encrypted packets, stop a saturated internet connection, learn every attack, fix arbitrary source code, or detect all rotating-IP/password-spray patterns. SQL signatures are bypassable; parameterized queries are the lasting fix. Per-IP controls can affect users behind shared NAT. Requests are limited to 16 KiB bodies and 8 KiB query strings; responses to 2 MiB; compressed request bodies and WebSockets are unsupported. SQLite writes run in the service process. Use one process only, not multiple Uvicorn workers. Benchmark and harden before using with real traffic.

## Full guide and evidence

Read `Team-B-Self-Healing-Guide.pdf` for the archive review, agent responsibilities, walkthroughs, evaluation plan, integration contract and production roadmap. `validation/` contains the actual local socket and source-repair results, with no tokens or private logs. A passing test suite is not a measured attack-detection accuracy rate.

## Relation to your ZIP files

This is a clean successor implementation informed by both uploads. The first supplied ZIP has a Suricata listener and a classify/analyze/explain graph. The second supplies an SRE investigator/mechanic/validator/PR workflow; its validator uses static AST checks and its README's success-rate claims were not independently established. This package implements actual HTTP enforcement and actual regression tests in the controlled patch lab. Original archives are unchanged. Their virtual environments, `.git` folders and `.env` file are not redistributed.
