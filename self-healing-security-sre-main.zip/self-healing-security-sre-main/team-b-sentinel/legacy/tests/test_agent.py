import json
from pathlib import Path
import select
import shutil
import socket
import subprocess
import sys
import time
import uuid

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import auto_repair_agent as agent
from repair_bridge import eligible

SOURCE = (Path(__file__).parent / 'lab_fixture.txt').read_bytes()


def event():
    return {'id': str(uuid.uuid4()), 'label': 'sql_injection', 'path': '/products',
            'origin': 'gateway', 'created': time.time()}


def port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


@pytest.fixture
def worker(tmp_path):
    (tmp_path / 'unsafe_demo.py').write_bytes(SOURCE)
    shutil.copy(agent.__file__, tmp_path / 'auto_repair_agent.py')
    instance = agent.Worker(tmp_path, '127.0.0.1', port())
    instance.start_app()
    instance.wait_ready()
    try:
        yield instance
    finally:
        instance.stop_app()


def test_patch_preserves_other_code_and_crlf():
    extra = b'\n# caf\xc3\xa9\n@app.post("/login")\ndef login():\n    return {"unchanged": True}\n'
    raw = SOURCE.replace(b'\n', b'\r\n') + extra
    fixed = agent.candidate_source(raw)
    assert fixed.endswith(extra)
    assert b'db.execute(query, (q,))' in fixed
    assert agent.candidate_source(fixed) == fixed


def test_unknown_source_refused():
    with pytest.raises(ValueError):
        agent.candidate_source(SOURCE.replace(b'WHERE name', b'WHERE price'))


def test_repair_and_duplicate(worker):
    trigger = event()
    report = worker.handle(trigger)
    assert report['baseline'] == {'normal': True, 'injection': False, 'apostrophe': False}
    assert report['status'] == 'repaired'
    assert report['live_http_tests'] == 'passed'
    assert (worker.run / 'unsafe_demo.py.bak').read_bytes() == SOURCE
    assert not worker.journal.exists()
    assert worker.handle(trigger) == report
    assert worker.handle(event())['status'] == 'already_safe'


def test_failed_candidate_leaves_source(worker, monkeypatch):
    monkeypatch.setattr(agent, 'candidate_source', lambda raw: raw)
    result = worker.handle(event())
    assert result['status'] == 'refused'
    assert worker.target.read_bytes() == SOURCE
    assert worker.healthy()


def test_post_apply_failure_rolls_back(worker, monkeypatch):
    def fail():
        raise RuntimeError('forced HTTP verification failure')
    monkeypatch.setattr(worker, 'verify', fail)
    result = worker.handle(event())
    assert result['status'] == 'rolled_back'
    assert worker.target.read_bytes() == SOURCE
    assert worker.healthy()


def test_concurrent_edit_not_overwritten(worker, monkeypatch):
    original_test = worker.test
    def edit():
        original_test()
        worker.target.write_bytes(SOURCE + b'\n# concurrent edit\n')
    monkeypatch.setattr(worker, 'test', edit)
    assert worker.handle(event())['status'] == 'refused'
    assert worker.target.read_bytes().endswith(b'# concurrent edit\n')


def test_invalid_event(worker):
    bad = event()
    bad['path'] = '/login'
    with pytest.raises(ValueError):
        worker.handle(bad)
    assert worker.target.read_bytes() == SOURCE


def test_crash_recovery(worker):
    worker.stop_app()
    fixed = agent.candidate_source(SOURCE)
    backup = worker.runs / 'crash.bak'
    backup.write_bytes(SOURCE)
    worker.target.write_bytes(fixed)
    agent.save_json(worker.journal, {'backup': 'crash.bak', 'original_hash': agent.digest(SOURCE),
                                    'candidate_hash': agent.digest(fixed)})
    worker.recover()
    assert worker.target.read_bytes() == SOURCE
    assert not worker.journal.exists()


def test_event_filter():
    trigger = event()
    assert eligible(trigger, trigger['created'] - 1, set())
    assert not eligible(trigger, trigger['created'] + 1, set())
    assert not eligible(trigger, 0, {trigger['id']})
    assert not eligible({**trigger, 'origin': 'collector'}, 0, set())
    assert not eligible({**trigger, 'label': 'brute_force'}, 0, set())


def test_real_worker_protocol(tmp_path):
    shutil.copy(agent.__file__, tmp_path / 'auto_repair_agent.py')
    (tmp_path / 'unsafe_demo.py').write_bytes(SOURCE)
    proc = subprocess.Popen([sys.executable, str(tmp_path / 'auto_repair_agent.py'),
                             '--host', '127.0.0.1', '--port', str(port())],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    def receive():
        assert select.select([proc.stdout], [], [], 25)[0], 'worker response timed out'
        line = proc.stdout.readline()
        assert line, proc.stderr.read().decode()
        return json.loads(line)
    try:
        assert receive()['type'] == 'ready'
        proc.stdin.write((json.dumps(event()) + '\n').encode())
        proc.stdin.flush()
        while True:
            result = receive()
            if result['type'] == 'result':
                assert result['report']['status'] == 'repaired'
                break
        proc.stdin.close()
        assert proc.wait(timeout=15) == 0
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait()


def test_bridge_over_real_ssh(tmp_path, monkeypatch):
    """Actual encrypted SSH/password auth and worker; simulated Sentinel feed."""
    import io
    import threading
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    import paramiko
    import repair_bridge as bridge

    lab = tmp_path / 'lab'
    windows = tmp_path / 'windows'
    lab.mkdir()
    windows.mkdir()
    shutil.copy(agent.__file__, lab / 'auto_repair_agent.py')
    (lab / 'unsafe_demo.py').write_bytes(SOURCE)
    (lab / '.venv').symlink_to(Path(sys.executable).parent.parent, target_is_directory=True)
    (windows / '.env').write_text('ADMIN_TOKEN=local-test-token\n')
    monkeypatch.setattr(bridge, '__file__', str(windows / 'repair_bridge.py'))
    private = Ed25519PrivateKey.generate().private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.OpenSSH, serialization.NoEncryption())
    key = paramiko.Ed25519Key.from_private_key(io.StringIO(private.decode()))
    listener = socket.socket()
    listener.bind(('127.0.0.1', 0))
    listener.listen(1)
    ssh_port = listener.getsockname()[1]
    app_port = port()
    errors = []

    class Server(paramiko.ServerInterface):
        command = None
        ready = threading.Event()
        def check_auth_password(self, username, password):
            return paramiko.AUTH_SUCCESSFUL if (username, password) == ('kali', 'test-only') else paramiko.AUTH_FAILED
        def get_allowed_auths(self, username):
            return 'password'
        def check_channel_request(self, kind, channel_id):
            return paramiko.OPEN_SUCCEEDED if kind == 'session' else paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED
        def check_channel_exec_request(self, channel, command):
            self.command = command.decode()
            self.ready.set()
            return True

    def serve():
        transport = None
        proc = None
        try:
            conn, _ = listener.accept()
            transport = paramiko.Transport(conn)
            transport.add_server_key(key)
            server = Server()
            transport.start_server(server=server)
            channel = transport.accept(10)
            assert channel and server.ready.wait(10)
            assert str(lab) in server.command and 'auto_repair_agent.py' in server.command
            # Execute the exact fixed bridge command in the temporary test lab.
            proc = subprocess.Popen(server.command, shell=True, stdin=subprocess.PIPE,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            def forward_input():
                try:
                    while data := channel.recv(4096):
                        proc.stdin.write(data)
                        proc.stdin.flush()
                finally:
                    proc.stdin.close()
            thread = threading.Thread(target=forward_input, daemon=True)
            thread.start()
            while True:
                ready, _, _ = select.select([proc.stdout, proc.stderr], [], [], 1)
                for stream in ready:
                    data = __import__('os').read(stream.fileno(), 4096)
                    if data:
                        (channel.sendall if stream is proc.stdout else channel.sendall_stderr)(data)
                if proc.poll() is not None:
                    break
            channel.send_exit_status(proc.returncode)
            thread.join(5)
            assert proc.returncode == 0
        except BaseException as exc:
            errors.append(exc)
        finally:
            if proc is not None and proc.poll() is None:
                proc.terminate()
                proc.wait(timeout=10)
            if transport:
                transport.close()
            listener.close()

    server_thread = threading.Thread(target=serve, daemon=True)
    server_thread.start()
    real_connect = socket.create_connection
    monkeypatch.setattr(bridge.socket, 'create_connection',
                        lambda addr, timeout=None: real_connect(('127.0.0.1', ssh_port), timeout))
    monkeypatch.setattr(bridge.getpass, 'getpass', lambda _: 'test-only')
    trigger = event()
    trigger['created'] += 1
    class Response:
        def raise_for_status(self):
            pass
        def json(self):
            return {'mode': 'live', 'incidents': [trigger]}
    class Feed:
        def __init__(self, **kwargs):
            assert kwargs['headers']['Authorization'] == 'Bearer local-test-token'
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass
        def get(self, path):
            assert path == '/api/state'
            if (windows / 'repair-events.jsonl').exists():
                raise KeyboardInterrupt()
            return Response()
    monkeypatch.setattr(bridge.httpx, 'Client', Feed)
    monkeypatch.setattr(sys, 'argv', ['repair_bridge.py', '--kali-ip', '127.0.0.1',
                                    '--app-port', str(app_port), '--lab-path', str(lab),
                                    '--host-fingerprint', bridge.fingerprint(key)])
    with pytest.raises(KeyboardInterrupt):
        bridge.main()
    server_thread.join(15)
    assert not server_thread.is_alive()
    assert not errors
    report = json.loads((windows / 'repair-events.jsonl').read_text())
    assert report['status'] == 'repaired'
    assert (lab / 'unsafe_demo.py').read_bytes() == agent.candidate_source(SOURCE)
