# Website

Published dashboard: https://sentinel-team-b.ashwinkp-cy23.chatgpt.site

For live use on your computer, start the Python service and open http://127.0.0.1:8000. The published dashboard offers a labeled demo and an HTTPS API connection form. It does not run the Python agent.
