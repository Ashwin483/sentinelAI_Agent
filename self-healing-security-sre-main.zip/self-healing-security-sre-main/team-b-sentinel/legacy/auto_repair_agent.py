"""Kali-only, narrowly scoped SQL repair worker. See START-HERE.md."""
import argparse
import ast
import difflib
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import select
import signal
import socket
import subprocess
import sys
import time
import types
import uuid
from typing import TypedDict

SQL = 'SELECT id, name, price FROM products WHERE name = ?'
ATTACK = "' OR 1=1--"
MOUSE = {'products': [{'id': 3, 'name': 'Mouse', 'price': 500}]}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic(path, data):
    tmp = path.with_name(path.name + '.repair-tmp')
    with open(tmp, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    if path.exists():
        os.chmod(tmp, path.stat().st_mode & 0o777)
    os.replace(tmp, path)


def save_json(path, data):
    atomic(path, (json.dumps(data, indent=2) + '\n').encode())


def candidate_source(raw):
    """Edit two AST-identified expressions; preserve all other source bytes."""
    tree = ast.parse(raw)
    funcs = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)
             and n.name == 'search_product']
    if len(funcs) != 1:
        raise ValueError('Expected exactly one search_product function')
    fn = funcs[0]
    assignments = [n for n in ast.walk(fn) if isinstance(n, ast.Assign)
                   and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)
                   and n.targets[0].id == 'query']
    calls = [n for n in ast.walk(fn) if isinstance(n, ast.Call)
             and isinstance(n.func, ast.Attribute) and n.func.attr == 'execute'
             and isinstance(n.func.value, ast.Name) and n.func.value.id == 'db'
             and n.args and isinstance(n.args[0], ast.Name) and n.args[0].id == 'query']
    if len(assignments) != 1 or len(calls) != 1:
        raise ValueError('Unknown query structure; human review required')
    value, call = assignments[0].value, calls[0]
    dump = lambda node: ast.dump(node, include_attributes=False)
    safe_value = ast.parse(repr(SQL), mode='eval').body
    safe_call = ast.parse('db.execute(query, (q,))', mode='eval').body
    if dump(value) == dump(safe_value) and dump(call) == dump(safe_call):
        return raw
    unsafe = ast.parse(repr("SELECT id, name, price FROM products WHERE name = '")
                       + " + q + \"'\"", mode='eval').body
    if dump(value) != dump(unsafe) or dump(call) != dump(ast.parse('db.execute(query)', mode='eval').body):
        raise ValueError('Source differs from approved SQL template; refusing to guess')
    lines = raw.splitlines(keepends=True)
    def offset(line, column):
        return sum(len(x) for x in lines[:line-1]) + column
    edits = [(offset(n.lineno, n.col_offset), offset(n.end_lineno, n.end_col_offset), replacement)
             for n, replacement in [(value, repr(SQL).encode()),
                                     (call, b'db.execute(query, (q,))')]]
    result = raw
    for begin, end, replacement in sorted(edits, reverse=True):
        result = result[:begin] + replacement + result[end:]
    ast.parse(result)
    return result


def load_app(path):
    module = types.ModuleType('unsafe_demo')
    module.__file__ = str(path)
    sys.modules['unsafe_demo'] = module
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    return module


def regression_check(path):
    module = load_app(path)
    checks = [('normal', 'Mouse', MOUSE), ('injection', ATTACK, {'products': []}),
              ('apostrophe', "O'Reilly", {'products': []})]
    results = {}
    for name, query, expected in checks:
        try:
            results[name] = module.search_product(query) == expected
        except Exception:
            results[name] = False
    print('REPAIR_TEST_RESULT=' + json.dumps(results))
    return 0 if all(results.values()) else 1


class State(TypedDict, total=False):
    phase: str
    error: str


class Worker:
    def __init__(self, root, host, port):
        self.root, self.host, self.port = root.resolve(), host, port
        self.target = self.root / 'unsafe_demo.py'
        self.runs = self.root / 'repair-runs'
        self.runs.mkdir(exist_ok=True)
        self.journal = self.runs / 'pending.json'
        self.child = None
        self.log = None
        self.trace = []
        self.report = {}
        from langgraph.graph import StateGraph, START, END
        graph = StateGraph(State)
        names = ['investigate', 'plan', 'test', 'apply', 'verify']
        for name in names:
            graph.add_node(name, self.guarded(name))
        graph.add_node('record', self.record)
        graph.add_edge(START, names[0])
        for index, name in enumerate(names):
            next_node = names[index+1] if index+1 < len(names) else 'record'
            graph.add_conditional_edges(name, lambda s: 'failed' if s.get('error') else 'ok',
                                        {'failed': 'record', 'ok': next_node})
        graph.add_edge('record', END)
        self.graph = graph.compile()

    def guarded(self, name):
        def node(state):
            self.trace.append(name)
            try:
                getattr(self, name)()
                return {'phase': name}
            except Exception as exc:
                self.report['error'] = str(exc)
                if self.journal.exists():
                    try:
                        self.trace.append('rollback')
                        self.stop_app()
                        self.recover()
                        self.start_app()
                        self.wait_ready()
                        self.report['status'] = 'rolled_back'
                    except Exception as rollback_error:
                        self.report['status'] = 'manual_intervention_required'
                        self.report['rollback_error'] = str(rollback_error)
                else:
                    self.report['status'] = 'refused'
                return {'error': str(exc), 'phase': name}
        return node

    def recover(self):
        if not self.journal.exists():
            return
        pending = json.loads(self.journal.read_text())
        backup_path = (self.runs / pending['backup']).resolve()
        if not backup_path.is_relative_to(self.runs.resolve()):
            raise RuntimeError('Invalid backup location')
        backup = backup_path.read_bytes()
        if digest(backup) != pending['original_hash']:
            raise RuntimeError('Backup hash mismatch')
        current = digest(self.target.read_bytes())
        if current == pending['candidate_hash']:
            atomic(self.target, backup)
        elif current != pending['original_hash']:
            raise RuntimeError('Concurrent edit detected; backup retained for manual review')
        self.journal.unlink()

    def start_app(self):
        with socket.socket() as check:
            check.bind((self.host, self.port))
        self.log = open(self.runs / 'app.log', 'ab', buffering=0)
        self.child = subprocess.Popen(
            [sys.executable, str(self.root / 'auto_repair_agent.py'), '--app-child',
             '--host', self.host, '--port', str(self.port)],
            cwd=self.root, stdout=self.log, stderr=subprocess.STDOUT, start_new_session=True)

    def stop_app(self):
        if self.child is not None:
            if self.child.poll() is None:
                os.killpg(self.child.pid, signal.SIGTERM)
                try:
                    self.child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(self.child.pid, signal.SIGKILL)
                    self.child.wait(timeout=5)
            self.child = None
        if self.log:
            self.log.close()
            self.log = None

    def healthy(self):
        import httpx
        if self.child is None or self.child.poll() is not None:
            return False
        try:
            with httpx.Client(trust_env=False, timeout=2) as client:
                response = client.get(f'http://{self.host}:{self.port}/health')
                return response.status_code == 200 and response.json() == {'status': 'ok'}
        except Exception:
            return False

    def wait_ready(self):
        for _ in range(30):
            if self.healthy():
                return
            if self.child is not None and self.child.poll() is not None:
                break
            time.sleep(0.2)
        raise RuntimeError('App did not become healthy; see repair-runs/app.log')

    def run_tests(self, source, log_name):
        process = subprocess.run([sys.executable, str(Path(__file__).resolve()), '--check', str(source)],
                                 cwd=self.root, capture_output=True, timeout=20)
        (self.run / log_name).write_bytes(process.stdout + process.stderr)
        prefix = b'REPAIR_TEST_RESULT='
        results = [line[len(prefix):] for line in process.stdout.splitlines() if line.startswith(prefix)]
        if len(results) != 1 or process.returncode not in (0, 1):
            raise RuntimeError('Regression process failed; inspect test logs')
        return json.loads(results[0])

    def investigate(self):
        self.original = self.target.read_bytes()
        self.report['original_hash'] = digest(self.original)
        baseline_path = self.run / 'baseline.py'
        baseline_path.write_bytes(self.original)
        self.report['baseline'] = self.run_tests(baseline_path, 'baseline-tests.log')
        if not self.report['baseline'].get('normal'):
            raise RuntimeError('Normal search is already broken; refusing automatic repair')

    def plan(self):
        self.candidate = candidate_source(self.original)
        (self.run / 'candidate.py').write_bytes(self.candidate)
        (self.run / 'patch.diff').write_text(''.join(difflib.unified_diff(
            self.original.decode().splitlines(True), self.candidate.decode().splitlines(True),
            fromfile='unsafe_demo.py.before', tofile='unsafe_demo.py.after')))
        self.report['candidate_hash'] = digest(self.candidate)

    def test(self):
        self.report['candidate_tests'] = self.run_tests(self.run / 'candidate.py', 'candidate-tests.log')
        if not all(self.report['candidate_tests'].values()):
            raise RuntimeError('Candidate failed regression tests; source left unchanged')

    def apply(self):
        if self.target.read_bytes() != self.original:
            raise RuntimeError('Source changed during repair; refusing overwrite')
        if self.candidate == self.original:
            self.report['status'] = 'already_safe'
            return
        backup = self.run / 'unsafe_demo.py.bak'
        backup.write_bytes(self.original)
        save_json(self.journal, {'backup': str(backup.relative_to(self.runs)),
                                'original_hash': digest(self.original),
                                'candidate_hash': digest(self.candidate)})
        self.stop_app()
        if self.target.read_bytes() != self.original:
            raise RuntimeError('Concurrent source edit; refusing overwrite')
        atomic(self.target, self.candidate)
        self.start_app()
        self.wait_ready()
        self.report['status'] = 'applied_pending_verification'

    def verify(self):
        import httpx
        self.wait_ready()
        with httpx.Client(trust_env=False, timeout=3) as client:
            for query, expected in [('Mouse', MOUSE), (ATTACK, {'products': []}),
                                    ("O'Reilly", {'products': []})]:
                response = client.get(f'http://{self.host}:{self.port}/products', params={'q': query})
                if response.status_code != 200 or response.json() != expected:
                    raise RuntimeError('Live HTTP regression check failed')
        if self.target.read_bytes() != self.candidate:
            raise RuntimeError('Source changed during verification')
        self.report['live_http_tests'] = 'passed'
        if self.report['status'] != 'already_safe':
            self.report['status'] = 'repaired'
        self.journal.unlink(missing_ok=True)

    def record(self, state):
        self.report.update(trace=self.trace, completed=time.time())
        save_json(self.run / 'report.json', self.report)
        save_json(self.runs / 'latest-report.json', self.report)
        return {'phase': 'record'}

    def handle(self, event):
        incident_id = str(uuid.UUID(event['id']))
        if event.get('label') != 'sql_injection' or event.get('path') != '/products':
            raise ValueError('Only sql_injection incidents for /products are supported')
        self.run = self.runs / incident_id
        if (self.run / 'report.json').exists():
            return json.loads((self.run / 'report.json').read_text())
        self.run.mkdir(exist_ok=True)
        self.trace = []
        self.report = {'incident_id': incident_id, 'started': time.time(), 'status': 'investigating'}
        self.graph.invoke({})
        return self.report


def emit(data):
    print(json.dumps(data), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='192.168.189.128')
    parser.add_argument('--port', type=int, default=9002)
    parser.add_argument('--check', type=Path)
    parser.add_argument('--app-child', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if args.check:
        return regression_check(args.check)
    address = ipaddress.ip_address(args.host)
    if not address.is_private or address.is_unspecified or address.version != 4:
        parser.error('Bind only to a specific private IPv4 address or 127.0.0.1')
    if args.app_child:
        import uvicorn
        uvicorn.run(load_app(root / 'unsafe_demo.py').app, host=args.host, port=args.port,
                    proxy_headers=False, access_log=False)
        return 0
    import fcntl
    lock = open(root / '.repair-agent.lock', 'w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    worker = Worker(root, args.host, args.port)
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, lambda *_: sys.exit(0))
    try:
        # Refuse an occupied port before crash recovery can alter the source.
        with socket.socket() as check:
            check.bind((args.host, args.port))
        worker.recover()
        worker.start_app()
        worker.wait_ready()
        emit({'type': 'ready', 'host': args.host, 'port': args.port})
        next_health = time.monotonic()
        # Binary unbuffered reads avoid stdin read-ahead blocking select().
        buffer = b''
        while True:
            if time.monotonic() >= next_health:
                status = {'type': 'health', 'healthy': worker.healthy(), 'time': time.time()}
                save_json(worker.runs / 'health.json', status)
                emit(status)
                next_health = time.monotonic() + 10
            readable, _, _ = select.select([sys.stdin], [], [], 1)
            if not readable:
                continue
            chunk = os.read(sys.stdin.fileno(), 4096)
            if not chunk:
                break
            buffer += chunk
            if len(buffer) > 8192:
                raise ValueError('Input too large')
            while b'\n' in buffer:
                line, buffer = buffer.split(b'\n', 1)
                try:
                    result = worker.handle(json.loads(line))
                    emit({'type': 'result', 'report': result})
                except Exception as exc:
                    emit({'type': 'error', 'message': str(exc)})
    finally:
        worker.stop_app()
        lock.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
