
## SENTINEL
Self-healing security agents

**Live SQL injection, HTTP flood and brute-force detection using LangGraph, with a working website dashboard.**

| Deliverable | What you receive |
| --- | --- |
| Runnable project | Python gateway, management API, protected lab app, LangGraph recovery agents and local website. |
| Live demonstration | Fixed, small loopback tests that generate real HTTP requests and visible incidents. |
| Source repair lab | A known SQL fixture repaired through a separate graph, backed by actual regression tests and a diff. |
| Detailed guide | Archive findings, Team B responsibilities, Windows setup, integration, verification and limitations. |

### Your first action

Extract the new ZIP and open its **team-b-sentinel** folder in VS Code. Follow the commands on page 10. Start the service, then open **http://127.0.0.1:8000**.

**Scope you can demonstrate honestly** This is an HTTP application-security prototype. It detects selected patterns and thresholds, applies temporary gateway protections, and records verification. It does not promise to identify every attack or withstand an internet-scale DDoS attack.

### What “self-healing” means here

For live traffic, recovery changes a narrowly scoped, expiring gateway rule. For source code, the included patch lab repairs a disposable, known SQL fixture. Arbitrary production-code repair remains a reviewed engineering task.

Prepared from the two supplied ZIP archives and the new implementation. No separate PDF was present in the supplied source-file listings. The new PDF is a project guide, not a claim that an existing PDF was reviewed.


## 01 / What your ZIP files contain

| Input | Observed behavior | Missing for this goal |
| --- | --- | --- |
| ai agents real(1).zip | Suricata listener reads eve.json. One signature ID maps to sql_injection. LangGraph runs detect, analyze and explain. Ollama is used for classification/explanation. | No HTTP gateway, live brute-force/flood counters, enforcement tool, rollback or operational website. |
| Self-Healing-SRE-Agent.zip | Investigator/mechanic/validator/PR workflow, application log reader, optional GitHub PR creation and a Streamlit UI. | Not a live attack detector. “run_tests” performs AST checks; it does not execute behavioral regression tests on the proposed repair. |

### Important review findings

**The first classifier receives a label and confidence, not enough raw evidence to independently establish the attack.** Its risk score is based on a fixed base value and configured weight. No CVE match is established by the label alone.

The SRE validator checks syntax, retained function names and bare exception handlers. Its documentation describes signature preservation, but the implementation compares function names rather than full argument signatures. These checks do not prove that a fix resolves the incident.

The SRE README includes success percentages, time and cost claims. The supplied code and evidence do not independently establish those figures, so this guide does not adopt them as your results.

### How the new package relates to them

The new project is a clean successor inspired by their orchestration structure. It adds a real gateway, evidence-based counters, reversible actions, actual local tests and a browser dashboard. Original archives are unchanged. Their installed environments, Git metadata and .env file are excluded from the new package.

Files reviewed: first ZIP: suricata_listener.py and backend/app/agents/*.py; second ZIP: README.md, graph.py, agents.py, tools.py and requirements.txt. No uploaded code was executed as part of this review.


## 02 / Architecture and trust boundaries

Traffic -> Gateway -> Application; Gateway -> Queue -> LangGraph; LangGraph -> SQLite; Dashboard -> Management API.

### Two paths serve different purposes

**Fast request path:** the gateway reads a bounded HTTP request, checks active rules and detector thresholds, and either forwards it to the fixed upstream or returns a security response. Failed logins are counted after the application responds.

**Recovery path:** an incident enters a bounded queue. LangGraph investigates evidence, creates an allowlisted plan, validates it, applies a temporary rule, checks the result and records the outcome. The LLM, when enabled, is outside the forwarding decision.

| Boundary | Contract |
| --- | --- |
| Client to gateway | Only socket client IP is trusted. Forwarded IP headers are ignored. The upstream destination cannot come from the request. |
| Gateway to application | The destination is configured in .env. The upstream must be private and expose /health. |
| Dashboard to API | An admin bearer token authorizes incident access and rollback. A different token authorizes collector ingestion. |
| Model to action | Model output is advisory text. It cannot select a shell command, change a label or execute a deployment. |

A fixed upstream and separate management plane reduce accidental exposure. They do not replace secure hosting, TLS, network policy or application authentication.


## 03 / Team B responsibilities

Because the uploads do not define your official team allocation, the following is a **proposed Team B scope**. Confirm ownership with your project group; no other team’s responsibility is assumed to be established.

| Workstream | Team B output | Acceptance evidence |
| --- | --- | --- |
| Detection | SQL signatures, per-source request windows, aggregate flood signal and failed-login counters. | Benign and suspicious requests produce the expected classification and HTTP response. |
| Orchestration | Typed incident state and conditional LangGraph transitions. | Node trace shows why a plan was applied, rejected or rolled back. |
| Mitigation | Scoped SQL guard, source/login cooldown and source block. | Rules are active only for the intended scope and expire. |
| Recovery | Prechecks, immediate verification, rollback and audit records. | A failed post-change health check removes the new rule. |
| Website | Connect agent, view/filter incidents, inspect evidence, export JSON and roll back. | Demo mode is clearly labeled; live mode uses authenticated API data. |
| Evaluation | Tests, controlled replay results, precision/recall and latency study plan. | Report measured results rather than inherited README claims. |

### Agent handoffs

**Investigator:** converts detector evidence into a reasoned incident summary. **Planner:** selects one known action. **Validator:** checks scope, benign behavior and upstream health. **Applier:** saves an expiring rule. **Verifier:** checks active policy and health. **Recorder:** stores the final outcome. A rollback node removes a failed change.

### Suggested implementation order

Demonstrate the protected lab first. Then integrate a real application with a clear authentication-result contract. Measure false positives and latency. Only after that, add trusted-proxy support, shared counters, durable workflow recovery and production deployment adapters.


## 04 / Events, collection and persistence

| Event field | Meaning |
| --- | --- |
| event_id | Stable unique string; duplicate IDs are ignored while retained in the in-memory deduplication cache. |
| source_ip | Validated IPv4 or IPv6 address. Gateway derives it from the socket; collector must obtain it from trusted logs. |
| method / path / query | HTTP context. Query is inspected but not stored verbatim in incident evidence. |
| body_text | Bounded request text for inspection. Excluded from normal Event serialization; never persisted as an incident body. |
| status / auth_failed | Application outcome. auth_failed must come from trusted authentication logic, not a user-submitted field. |
| origin | Gateway or collector. The API forces collector origin for ingested events. |

```
{"event_id":"login-0001","source_ip":"192.0.2.10",
 "method":"POST","path":"/login",
 "status":401,"auth_failed":true}
```

### Collector integration

Write one normalized event per line to events.jsonl. Start **collector.py events.jsonl** to follow new lines. The file adapter handles truncation/rotation and limits line size. It retries delivery three times, but has no durable delivery spool or persisted offset. Supply stable event IDs to make retries deduplicable.

The collector is an adapter for normalized JSONL, not a parser for raw IIS logs, Windows Event Viewer exports or arbitrary PDF files. Those formats need their own normalization step. Log collection is after-the-fact; only gateway-routed traffic can be blocked by this project.

### Stored data and restart behavior

SQLite retains up to 2,000 incidents and 10,000 audit entries; the dashboard returns the latest 100 incidents. Rules retain expiry across restart. Rate windows, queue contents and deduplication memory reset. Interrupted incidents are marked for review; there is no durable LangGraph checkpoint/resume implementation.


## 05 / SQL injection: detect and repair

### Detection in the delivered code

The gateway examines path, query and bounded body text. It decodes URL escaping twice, normalizes JSON text and SQL comments, and checks four signature groups: UNION SELECT, quote-based Boolean comparisons, selected time-delay functions, and stacked schema-changing statements. Evidence stores the signature identifier and a request fingerprint, not the raw password or payload.

```
Example suspicious input:  q=' OR 1=1--
Example ordinary input:    q=O'Reilly
```

A match immediately returns **403** before the upstream receives that request. LangGraph may add an expiring SQL guard on the affected route after policy checks and a healthy upstream precheck. An active additional rule returns **429**.

### Permanent repair

The lasting fix is to keep user data separate from SQL syntax using parameter binding. The protected lab already does this. Its safe query is shown below. OWASP lists prepared statements with parameterized queries as a primary defense [1].

```
rows = db.execute(
    "SELECT id,name FROM products WHERE name = ?",
    (q,)
).fetchall()
```

### How to present this in your demonstration

Send the suspicious request through port 8080 and show the block. Open the incident and its signature evidence. Then send q=book and show a valid result. Open the source-patch proposal to explain why runtime containment and application-code repair are separate steps.

**Detection limit** These signatures are a small starting rule set, not a complete SQL parser or production WAF. Obfuscated, second-order, application-specific and previously unseen attacks can bypass them. A signature match is evidence of suspicious syntax, not proof of exploitation.

The isolated **patch_lab.py** demonstrates an actual unsafe query being repaired and verified. It is described on page 12 and does not modify your protected application.


## 06 / Brute force: use real outcomes

### The authentication contract matters

In the included lab, a **401 response on the configured LOGIN_PATH** means a failed sign-in. The gateway counts that server response. It does not classify every login attempt as an attack. Successful sign-ins do not increment failure counts.

| Setting / behavior | Default implementation |
| --- | --- |
| LOGIN_PATH | /login; exact route matching. |
| LOGIN_LIMIT / LOGIN_WINDOW | Five failures from the same source within 60 seconds. |
| Immediate effect | The fifth failure is observed; the next matching login request is rejected. |
| Agent action | Temporary login_cooldown scoped to source IP and login route. |
| Other routes / clients | Other routes for that source remain usable; unrelated sources are not covered by this rule. |
| Expiry and rollback | Additional rule expires after 120 seconds. Base failure counters remain until their 60-second window ages out. |

### Example

The replay sends six deliberately incorrect credentials to the local lab. The first five responses are 401; the sixth is 429. Once the agent completes, the incident shows the failure count, time window, action and verification. The lab credentials are **student / sentinel-lab-only**; they are demonstration values and create no production login session.

### Adaptation to your own application

Some applications return 200 with an error field, use multiple login routes, or implement external identity providers. In those cases, change the trusted result adapter or send normalized events from the authentication code. A request field named auth_failed is not a trustworthy signal.

**Coverage gap to explain** This version tracks failures per source IP. It does not implement per-account throttling, distributed password-spray correlation, device identity or MFA. Rotating-IP attacks may evade its threshold. Shared NAT can cause several people to share a cooldown.

For real services, design throttling with account-level context and MFA. OWASP discusses login throttling, lockout considerations and MFA as complementary defenses [2].


## 07 / HTTP floods and DDoS signals

DDoS means an attack from distributed sources. A fast sequence from one laptop proves only a source-rate threshold. The system therefore labels this category **HTTP flood / DDoS signal**, without claiming every burst is a distributed attack.

| Signal | Trigger | Response |
| --- | --- | --- |
| Per-source flood | 60 observed requests from one source within 10 seconds. | Immediate 429. The graph can apply a source block for 120 seconds. |
| Aggregate pressure | 300 observed requests within 10 seconds and at least five distinct source IPs. | Flag possible distributed HTTP pressure; escalate the ambiguous aggregate case instead of selecting an arbitrary IP to block. |
| Concurrent overload | 50 requests in the gateway handler at once. | Return 503 with a short Retry-After. No LLM call is needed. |
| Bounded request handling | Body over 16 KiB, query over 8 KiB, compressed body or slow body read. | Reject unsupported or oversized input. The body-read timeout is five seconds. |

### Why upstream protection is still needed

An application agent cannot free an internet link that is already saturated before traffic reaches it. Large floods need controls at the CDN, reverse proxy, provider or network edge. This project does not inspect UDP/SYN floods, raw packets or encrypted TLS records. OWASP treats denial of service as a problem spanning multiple layers [3].

### Tuning without guessing

Measure legitimate per-source and aggregate request distributions first. Examine event traffic, shared NAT users, retry bursts and health checks. Use those observations to tune IP_LIMIT, GLOBAL_LIMIT and the windows. Watch source evictions and dropped incidents: saturation means visibility has degraded.

**False-positive risk** A busy event or flash crowd can resemble a flood. The aggregate detector is a threshold signal, not a trained anomaly model. Base overload guards can reject legitimate requests while the threshold remains exceeded; assess that behavior before deployment.


## 08 / Self-healing and rollback logic

| Stage | Decision and evidence |
| --- | --- |
| Investigate | Classify using detector evidence. Optionally add a local model explanation. No CVE is invented. |
| Plan | Select sql_guard, login_cooldown or source_block. Ambiguous aggregate evidence selects escalation. |
| Validate | Check the target is not the reserved health path. Check that the rule matches a bad test event but permits the benign comparison. Require upstream /health = 200. |
| Apply | Write a rule with a unique ID, incident ownership and expiry. Existing rules are preserved. |
| Verify | Check that the new policy is active and upstream /health still returns 200. |
| Failure path | Failed precheck: no change, escalate. Failed postcheck: remove the new rule. Node exception after application: remove rules owned by that incident. |
| Record | Persist the trace and final status: mitigated, escalated, rolled_back or failed. |

### What verification proves

The online verifier confirms a limited immediate condition: the intended policy is present and the upstream health endpoint is responsive. It does not replay the entire user journey or prove sustained recovery under load. The integration tests separately exercise actual gateway behavior with benign and suspicious requests.

### What rollback does

Rollback disables the additional rule identified by its ID. It does not clear detector history, erase the incident, remove baseline protections or disable other incidents’ rules. Consequently, a source can still receive 429 while a base rate or failure window is exceeded.

### Why the automatic change is bounded

There are no LLM-selected shell commands, administrator firewall edits or arbitrary production file writes. The graph has a recursion limit of 12 and a single bounded worker queue. Expiring rules limit long-lived harm from false positives. Operator review remains necessary when evidence is ambiguous or a source-code change is needed.


## 09 / Windows setup: step by step

**1.** Extract Team-B-Sentinel.zip. Open the extracted **team-b-sentinel** folder in VS Code. Choose Terminal &gt; New Terminal. Use Python 3.12, matching the tested interpreter version.

```
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe setup_env.py
.\.venv\Scripts\python.exe start.py
```

These commands use the virtual-environment interpreter directly, so PowerShell script-activation policy does not need to change. If py -3.12 is unavailable, install/select Python 3.12 or explicitly use your compatible interpreter; other versions were not validated here.

**2.** Keep the terminal running. Open **http://127.0.0.1:8000** in your browser. Open .env in VS Code and copy only the value after ADMIN_TOKEN=. Do not include the variable name or quotes.

**3.** In the dashboard, set API address to **http://127.0.0.1:8000**, paste the admin token and click **Connect**. The mode badge should show LIVE AGENT. Empty counters before traffic are normal.

| Port | Purpose | What to open |
| --- | --- | --- |
| 8000 | Local management website and API. | Use this for the dashboard. |
| 8080 | Protected gateway. | Send application requests here. |
| 9000 | Example upstream application. | Private loopback service; direct requests bypass inspection. |

**4.** Open a second VS Code terminal for tests. Leave the first running. Stop the system with Ctrl+C in the first terminal when finished.

### Package contents

start.py starts the services; sentinel/core.py contains detectors and graph; sentinel/web.py contains gateway/API; lab_app.py is the example app; website/ contains the browser interface; tests/ contains behavioral tests; validation/ contains the measured results; patch_lab.py demonstrates source repair.

Setup commands are Windows-oriented. Execution was validated on Linux with Python 3.12; a Windows-host run remains your next environment check. No administrator rights are required for the default loopback setup.


## 10 / Live demo and expected results

Use a second terminal in the project folder. Run the cases in this order so a flood block does not hide the earlier demonstrations. The scripts accept only these case names and always target loopback.

```
.\.venv\Scripts\python.exe replay_local.py sql
.\.venv\Scripts\python.exe replay_local.py brute
.\.venv\Scripts\python.exe replay_local.py flood
```

| Observed local socket test | Actual result |
| --- | --- |
| SQL syntax test | 403 for the suspicious request; normal product search returned 200. |
| Failed-login test | First five requests returned 401; sixth returned 429. |
| 65-request flood replay | 52 responses were 200 and 13 were 429. Earlier requests shared the same 10-second window. |
| Authenticated management API | 200; SQL injection, brute-force and HTTP flood incidents reached mitigated. |
| Process shutdown | The multi-service process exited cleanly with status 0 after an interrupt. |

### What to show on the website

Select each incident. Point to the source IP, route, evidence, agent trace and temporary rule. Export the incident JSON as evidence for your report. For an SQL incident, open the source-patch proposal. Use Roll back protection to demonstrate removal of the additional rule.

The website refreshes every three seconds. If the incident is still queued, wait for its agent trace. Optional model inference may add delay. The fast signature/rate guards do not wait for that model.

### Resetting between independent experiments

Wait for the relevant windows and rules to expire: 10 seconds for rate windows, 60 seconds for failures and 120 seconds for additional rules by default. Restart clears in-memory windows but leaves unexpired SQLite rules. Rollback does not clear baseline counters. Retain the audit trail when recording experiments.

**Demo website versus live service** Explore demo cases loads sample objects in the browser only. It sends no traffic and changes no real rule. Live mode appears only after a successful authenticated connection to the Python API.


## 11 / Actual source repair in the lab

The supplied SRE project uses static code checks. The new patch lab demonstrates the stronger sequence: establish a behavioral failure, produce a targeted fix, run actual tests, apply it to the known fixture and verify again.

```
.\.venv\Scripts\python.exe patch_lab.py
```

| Step | Implemented behavior |
| --- | --- |
| Create fixture | Write a known unsafe SQLite query into a new local output directory. It is not served on the network. |
| Investigate | Run pytest against the original. The expected baseline exit code is 1, showing failed security/edge-case tests. |
| Repair | Generate a unified diff replacing SQL string concatenation with a bound parameter. This repair is deterministic. |
| Validate | Run normal lookup, SQL-like-input and apostrophe-input tests against the candidate. Require exit code 0. |
| Apply | Check the original file hash to detect intervening changes, then atomically replace the fixture file. |
| Verify / rollback | Run tests again after apply. Restore the original fixture if post-apply validation fails. |

### Files to inspect

**proposed.patch** is the exact diff. **baseline-tests.txt** captures the original failure. **candidate-tests.txt** and **post-apply-tests.txt** capture the passing repair. **target.py.before** is the backup. **result.json** records the original hash and return codes.

The delivered validation evidence shows baseline exit **1**, candidate exit **0**, and a successful fixture repair. The candidate and post-apply suites each pass three tests. This establishes behavior for this fixture only.

```
# A second run keeps the first run as evidence:
.\.venv\Scripts\python.exe patch_lab.py --output patch-output-2
```

**Production source is unchanged** The script does not ingest arbitrary repositories, execute model-generated code, patch your uploaded archives or push a PR. Applying a fix to your actual application requires its source context, regression suite, deployment procedure and review.


## 12 / AI, offline use and efficiency

### LangGraph is the orchestrator

The graph uses shared typed state, callable nodes and conditional edges. Some nodes are ordinary code; they need not all call a language model. The current system uses deterministic detection and action policy, with optional LLM-assisted investigation. This matches the separation of state, nodes and edges described in LangGraph documentation [4].

### Enable the local model only when ready

Run Ollama locally and install a model supported by your machine. Use **ollama list** to find the exact installed model name. Set that name in .env and restart start.py. No model is downloaded by the project itself.

```
OLLAMA_MODEL=your-installed-model-name
OLLAMA_URL=http://127.0.0.1:11434
```

The implementation calls Ollama /api/chat with streaming disabled, structured evidence, temperature 0 and a bounded output request. Model text appears as advisory explanation. It cannot change the detector label or execute actions. The HTTP timeout is eight seconds, with deterministic fallback if inference fails [5].

### What works without internet

After Python dependencies and any chosen local model have been downloaded, the gateway, SQLite records, local dashboard, tests and deterministic graphs can run without internet. The local website has no external fonts, scripts or CDN dependencies. Hosted website access and initial downloads still need a connection.

| Efficiency choice | Benefit and remaining limit |
| --- | --- |
| Fast path separated from model | No per-request LLM wait. A single incident worker can still fall behind during many distinct incidents. |
| Bounded caches and queue | Up to 10,000 tracked sources, 20,000 deduplication IDs and 256 queued incidents. Eviction/drop counters expose saturation. |
| Request and connection limits | Bound body size, body-read time and concurrency. This is not a defense against link saturation. |
| SQLite persistence | Simple and inspectable. Synchronous queries/writes share the service process and require workload testing. |

No trained classifier, learned anomaly model, calibrated confidence score or production throughput benchmark is included. An LLM service was not run during validation; its live inference remains untested.


## 13 / Testing and evaluation plan

```
.\.venv\Scripts\python.exe -m pytest -q
```

**Delivered test result: 21 passed in 0.43 seconds** in the final local run. This is suite runtime on the available Linux/Python 3.12 environment, not a throughput benchmark or measured attack-detection accuracy.

| Test group | Evidence covered |
| --- | --- |
| SQL handling | Common signatures, URL/double encoding, comments, JSON escapes and selected benign text. |
| State and load bounds | Event deduplication, threshold behavior, bounded source memory and queue overflow. |
| Agent decisions | Scoped SQL policy, precheck escalation, postcheck rollback and ambiguous aggregate escalation. |
| Persistence | Rule survival across reopen and expiry filtering. |
| Application integration | Actual ASGI forwarding, SQL block, normal search, failed-login handling, source flood and other-client access. |
| Security boundaries | Admin/collector token separation, ignored spoofed IP header, no persisted password text and no cross-client cookie leakage. |

### Measure accuracy with a labeled set

Build a held-out collection containing normal traffic, SQL variants, failed-login sequences, normal retry bursts and legitimate busy periods. Keep tuning traffic separate from the final evaluation. Label both individual requests and attack episodes. Report misses and false alarms for each attack category, not just one overall percentage.

```
Precision = TP / (TP + FP)
Recall    = TP / (TP + FN)
F1        = 2 * Precision * Recall / (Precision + Recall)
FPR       = FP / (FP + TN)
```

Report undefined ratios as N/A rather than inventing a value. Include the sample count and labeling method. For brute force and floods, declare whether TP represents a request, source, window or attack episode.

### Measure performance and recovery

Record p50/p95/p99 request latency with and without the gateway, queue delay, detection-to-action time, false-block rate, CPU/memory use and dropped incidents. For recovery, add sustained availability checks and real user-journey probes. The immediate /health verifier is not sufficient for an MTTR claim.


## 14 / Integrating your real application

**1. Define the boundary.** Identify the one application to protect, its private listening origin, TLS termination and trusted authentication result. Do not assume this gateway monitors the entire Windows computer.

```
START_LAB=false
UPSTREAM_URL=http://127.0.0.1:YOUR_APP_PORT
LOGIN_PATH=/your-login-route
```

**2. Add health.** Provide GET /health returning 200 when the application can serve its intended work. A superficial always-200 response weakens the recovery check.

**3. Route traffic.** Make clients use the gateway on port 8080. Restrict the upstream port to the gateway or local process boundary. Sending traffic directly to the upstream bypasses detection. GATEWAY_HOST can be changed for an authorized private-network demonstration; the management service remains loopback by default.

**4. Integrate authentication.** If failures are not represented by 401 on the configured route, normalize trusted events or modify the adapter. Include a stable event ID and source identity. Add per-account/rotating-IP detection before claiming password-spray coverage.

**5. Handle a front proxy explicitly.** The current gateway ignores X-Forwarded-For and related headers. Behind a proxy, all users may look like one source. Implement a trusted-proxy allowlist and validated client-IP parsing before using source thresholds there. Never trust arbitrary forwarded headers.

**6. Keep the website connection realistic.** A remotely hosted dashboard cannot host the Python agent or automatically see your laptop. The easiest live path is the local dashboard. A remote deployment needs a separately hosted HTTPS management API, network access controls and an exact ALLOWED_ORIGINS value.

### Next production engineering steps

Use a mature reverse proxy/WAF and upstream DDoS service; shared atomic rate counters; durable queues and workflow checkpoints; authenticated operator identities; central audit retention; tested trusted proxies; per-account controls; rollout/canary and rollback adapters; secrets management; measured resource budgets and service-level verification.

**Deploy only after measuring your workload** This single-process gateway is suitable for a controlled project demonstration. It is not a transparent replacement for a production reverse proxy: WebSockets, streaming/large responses, compressed request bodies and multi-worker state sharing are not supported.


## 15 / Troubleshooting and API reference

| Symptom | What to check |
| --- | --- |
| ModuleNotFoundError | Run pip through the same .venv interpreter used for start.py. Do not use an unrelated global Python. |
| 401 in the dashboard | Use ADMIN_TOKEN, not COLLECTOR_TOKEN. Paste only its value. setup_env.py preserves an existing .env. |
| No incidents | Confirm LIVE AGENT mode and send requests to port 8080. Direct requests to 9000 bypass protection. |
| 502 from gateway | Start the upstream app; verify UPSTREAM_URL and its /health endpoint. For the example use START_LAB=true. |
| Escalated incident | The precheck may have failed, the path may be /health, or the incident may describe ambiguous aggregate pressure. |
| 429 after rollback | Baseline rate/failure counters still apply. Wait for the window to expire; check other active rules. |
| Address already in use | Stop the earlier instance using its terminal. Check 8000, 8080 and 9000 before starting another copy. |
| Hosted dashboard cannot connect | Use the local dashboard for HTTP loopback. A remote API needs HTTPS, exact CORS configuration and network reachability. |
| Model unavailable | Check Ollama is running and OLLAMA_MODEL exactly matches an installed model. Deterministic fallback remains available. |

### Management API

| Method and path | Authorization / outcome |
| --- | --- |
| GET /api/health | No token; returns the minimal service identity. |
| GET /api/state | Admin bearer token; recent incidents, active rules, audit and process counters. |
| POST /api/events | Collector bearer token; accepts one bounded normalized Event. |
| POST /api/rules/{id}/rollback | Admin bearer token; disables one additional active policy or returns 404. |

No API endpoint grants shell execution, uploads arbitrary code, changes OS firewall rules or resets audit history. The gateway and management API are separate FastAPI applications started in one process.


## 16 / Evidence, references and handover

### Evidence delivered with the ZIP

validation/socket-validation.json records the real local HTTP demonstration. validation/patch-result.json, proposed.patch and the baseline/candidate/post-apply logs record the controlled source-repair experiment. tests/test_system.py contains the behavioral test suite. README.md contains the quick-start and integration notes.

### Unverified items to state in your report

Windows-host execution, browser-rendered UI QA, optional Ollama inference, internet-scale DDoS performance, model accuracy, production authentication, sustained post-change recovery and repair of your actual application source were not established. The hosted website is a separate dashboard surface; the Python service runs where you install it.

### Primary technical references

**[1] OWASP: SQL Injection Prevention**<br/>Parameterized queries and separation of data from SQL syntax.<br/><link href="https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html" color="#245e82">https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html</link>

**[2] OWASP: Authentication**<br/>Login throttling, account-lockout design and MFA considerations.<br/><link href="https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html" color="#245e82">https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html</link>

**[3] OWASP: Denial of Service**<br/>Layered treatment of denial-of-service risks and resource limits.<br/><link href="https://cheatsheetseries.owasp.org/cheatsheets/Denial_of_Service_Cheat_Sheet.html" color="#245e82">https://cheatsheetseries.owasp.org/cheatsheets/Denial_of_Service_Cheat_Sheet.html</link>

**[4] LangChain: LangGraph Graph API**<br/>State, nodes, edges, compilation and conditional workflows.<br/><link href="https://docs.langchain.com/oss/python/langgraph/graph-api" color="#245e82">https://docs.langchain.com/oss/python/langgraph/graph-api</link>

**[5] Ollama: Generate a chat message**<br/>The /api/chat request, model/messages inputs and streaming option.<br/><link href="https://docs.ollama.com/api/chat" color="#245e82">https://docs.ollama.com/api/chat</link>

References accessed 12 September 2026. Implementation-specific claims above are based on the delivered code and recorded tests; the references do not certify this prototype.

### A concise viva explanation

“Our Team B prototype places an HTTP gateway before the application. Fast rules inspect suspicious SQL syntax, request rates and failed logins. LangGraph coordinates evidence analysis, scoped mitigation, validation and rollback. The dashboard exposes each decision. We verify a source repair with real tests in an isolated SQL fixture, while keeping production code changes reviewable.”
