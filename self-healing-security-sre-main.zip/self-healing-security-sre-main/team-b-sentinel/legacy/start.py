"""Start the dashboard, gateway and optional lab in one Windows-friendly process."""
import asyncio
import os
import signal
from contextlib import contextmanager
from pathlib import Path
from dotenv import load_dotenv
import uvicorn
from sentinel.core import Engine, Store, Settings
from sentinel.web import create_apps

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / '.env')

def integer(name, default):
    return int(os.getenv(name, str(default)))

class Server(uvicorn.Server):
    @contextmanager
    def capture_signals(self):
        yield

async def main():
    cfg = Settings(ip_limit=integer('IP_LIMIT',60), global_limit=integer('GLOBAL_LIMIT',300),
                   min_sources=integer('MIN_SOURCES',5), login_limit=integer('LOGIN_LIMIT',5),
                   flood_window=integer('FLOOD_WINDOW',10), login_window=integer('LOGIN_WINDOW',60),
                   rule_ttl=integer('RULE_TTL',120), login_path=os.getenv('LOGIN_PATH','/login'),
                   llm_model=os.getenv('OLLAMA_MODEL',''), ollama_url=os.getenv('OLLAMA_URL','http://127.0.0.1:11434'))
    (ROOT/'data').mkdir(exist_ok=True)
    engine = Engine(Store(str(ROOT/'data'/'sentinel.db')), cfg)
    origins = [x.strip() for x in os.getenv('ALLOWED_ORIGINS','').split(',') if x.strip()]
    management, gateway = create_apps(engine, os.getenv('UPSTREAM_URL','http://127.0.0.1:9000'),
        os.getenv('ADMIN_TOKEN',''), os.getenv('COLLECTOR_TOKEN',''), ROOT/'website', origins)
    servers = [Server(uvicorn.Config(management,host='127.0.0.1',port=8000,proxy_headers=False,access_log=False)),
               Server(uvicorn.Config(gateway,host=os.getenv('GATEWAY_HOST','127.0.0.1'),port=8080,
                                             proxy_headers=False,access_log=False,limit_concurrency=100))]
    if os.getenv('START_LAB','true').lower() == 'true':
        from lab_app import app
        servers.append(Server(uvicorn.Config(app,host='127.0.0.1',port=9000,proxy_headers=False,access_log=False)))
    def stop(signum, frame):
        for server in servers:
            server.should_exit = True
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    print('Dashboard: http://127.0.0.1:8000 | Protected gateway: http://127.0.0.1:8080')
    try:
        await asyncio.gather(*(s.serve() for s in servers))
    finally:
        for s in servers:
            s.should_exit = True

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
